//
//  Constants.swift
//  Sunny
//
//  Created by Maksim Halubko on 21.02.22.

import Foundation

let apiKey = "358389cc2e7b7f987ac85f1075b911c6"
